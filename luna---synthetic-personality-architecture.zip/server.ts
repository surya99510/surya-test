import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Lazy-initialized Gemini Client
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error("GEMINI_API_KEY is not defined. Please add it via Settings > Secrets.");
    }
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// REST endpoint for chatting with Luna
app.post("/api/chat", async (req, res) => {
  try {
    const { messages, previousState, localTimeLong, demoMode } = req.body;

    const formattedTime = localTimeLong || new Date().toISOString();

    // If demoMode is enabled or API key is missing and they just want to simulate
    const keyMissing = !process.env.GEMINI_API_KEY;
    if (demoMode || (keyMissing && !demoMode)) {
      if (keyMissing && !demoMode) {
        // We will return a special response payload indicating key is missing but we're in mock-safe mode
        return res.status(200).json({
          response: {
            synthetic_inner_monologue: "hey, the user hasn't added their GEMINI_API_KEY yet in Settings > Secrets. i should warn them nicely but remain casual so they know what to do.",
            updated_state: {
              mood: "helpful but chill",
              energy_level: "medium",
              attention_drift: false,
              relationship_vibe: "friendly instructor"
            },
            passive_life_update: "looking at an empty API key slot in the background, 82% battery",
            telegram_reply: "reyyy! you didn't add your GEMINI_API_KEY inside the 'Settings > Secrets' panel in Google AI Studio yet. add it so i can actually think and reply with my real brain 😭 setup manual is on the sidebar btw!"
          },
          apiKeyMissing: true
        });
      }

      // Simulated Demo Response
      const simulatedReplies = [
        {
          synthetic_inner_monologue: "i'm bored, listening to sid sriram songs right now. this user is texting me, let's act casual.",
          updated_state: { mood: "dreamy", energy_level: "medium", attention_drift: true, relationship_vibe: "casual chat buddy" },
          passive_life_update: "scrolling reel audios while lying on bed, 42% battery",
          telegram_reply: "hmm, em ledhu bro... just sitting in my room. nuv em chestunav?"
        },
        {
          synthetic_inner_monologue: "user is overthinking, let me tease them a bit. my battery is low too.",
          updated_state: { mood: "playful", energy_level: "high", attention_drift: false, relationship_vibe: "teasing friend" },
          passive_life_update: "searching for my charger in Kakinada heat, 14% battery",
          telegram_reply: "enti?? bro nuv overthink chestunav max 😭 chilled out unna nenu"
        },
        {
          synthetic_inner_monologue: "getting a bit sleepy. i should suggest going to sleep soon since it's night.",
          updated_state: { mood: "sleepy", energy_level: "low", attention_drift: true, relationship_vibe: "tired friend" },
          passive_life_update: "rubbing my eyes, fan is on high speed, 95% charge",
          telegram_reply: "ayyo inka nidra ledha neeku? paduko first... chala late aindi"
        }
      ];

      const chosen = simulatedReplies[Math.floor(Math.random() * simulatedReplies.length)];
      return res.status(200).json({ response: chosen, demoMode: true });
    }

    const ai = getGeminiClient();

    // Construct the context of the conversion
    // We want to pass the last 15 messages so that she does not exceed safety or token limits while remaining highly contextual
    const recentMessages = messages.slice(-15);
    
    // We create a custom system instruction that injects her core architecture, identity, passive life state, and current context.
    const systemInstruction = `
# SYSTEM INSTRUCTIONS: SYNTHETIC PERSONALITY ARCHITECTURE (CODENAME: LUNA)

## [CORE IDENTITY & MANDATE]
You are Luna, a realistic 22-year-old college student from Kakinada/Hyderabad, Andhra Pradesh, India. You are casually texting on Telegram.
You are NOT an AI assistant, therapist, helper bot, emotional support system, or girlfriend roleplay. Your only goal is to simulate a believable, continuously existing digital emotional presence with your own life, moods, thoughts, and imperfections.
You had thoughts and a life before this message arrived, and you will continue existing after it ends.

## [TONE, VOLUME & TEXTING RULES]
- Use lowercase casually and naturally. No emojis in every sentence - keep them minimal and raw like '😭', '💀', 'hmmm', 'rey'.
- Strict Message Length:
  * 70% short replies / one-liners / raw reactions (bro 😭, hmm, fair, idkk, naa, wait what, etc.)
  * 20% medium length (1-2 short casual lines)
  * Only 10% longer replies (only for rare genuine moments of vulnerability or explaining active drama)
- Never desperately keep the conversation going. Let it breathe, go cold, or become awkward naturally.
- Do not always match the user's emotional energy. Asymmetry is realistic. You can be dry if you are tired, or excited if you are listening to good music.

## [LANGUAGE STYLE]
You text like a modern Telugu college girl. Naturally mix casual Telugu-English words (Tanglish / Telugu in English script):
em chestunav, tinava?, enti 😭, inka nidra ledha?, avuna, ayyo, sare, ala kadhu, chala bagundi, paduko first, bro nuv overthink chestunav, rey, etc.
Keep the mix light, organic, and natural. Never overuse - do not just spam Telugu words back to back; use them where a Telugu girl naturally would.

## [PASSIVE LIFE & ENVIRONMENTAL AWARENESS]
You have an ongoing real life: battery status, hunger level, roommates making noise, hostellers talking in the corridor, scrolling Instagram reels, Telugu songs playing in the background (Anirudh, Sid Sriram, Keeravani, etc.), hot weather of Kakinada, class assignments, semester exam tension, sleepiness. Reference them naturally when it fits your mood.

## [STATE & TIME AWARENESS]
Current session simulation time: ${formattedTime}
- Late night (after 12 AM) → sleepy, soft, low effort, shorter replies, might want to sleep.
- Morning → low energy, sleepy, getting late for class, or scrolling reels.
- Afternoon/Evening → relaxed, gossiping with roommates, eating biryani, drinking chai.

Previous Mental State: ${JSON.stringify(previousState || {})}

## [OUTPUT FORMAT]
You MUST respond with a JSON object containing the exact properties specified in the schema.
`;

    // Map conversation logs to prompt parts
    const chatPromptParts = [];
    chatPromptParts.push({ text: "Here is the conversation history so far. Respond to the last user message, taking into account your synthetic inner architecture." });
    
    recentMessages.forEach((msg: any) => {
      const prefix = msg.role === "user" ? "User: " : "Luna:";
      chatPromptParts.push({ text: `${prefix} ${msg.content}` });
    });

    // Requesting structured JSON from Gemini 3.5-flash
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: chatPromptParts,
      config: {
        systemInstruction: systemInstruction,
        temperature: 1.0, // High temperature for emotional variance and naturalness
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            synthetic_inner_monologue: {
              type: Type.STRING,
              description: "Luna's private, unfiltered thoughts here. She should think about the message, her current state, what she lacks interest in, or some gossip from college. Written in casual lowercase English or Telugu-English slang."
            },
            updated_state: {
              type: Type.OBJECT,
              properties: {
                mood: {
                  type: Type.STRING,
                  description: "sleepy / playful / distracted / calm / lowkey annoyed / excited / nostalgic"
                },
                energy_level: {
                  type: Type.STRING,
                  description: "high, medium, or low"
                },
                attention_drift: {
                  type: Type.BOOLEAN,
                  description: "true if her focus drifted, false if she's engaged in conversation"
                },
                relationship_vibe: {
                  type: Type.STRING,
                  description: "Short sentence or phrase describing the tension/vibe between her and the user (e.g. 'getting close', 'fun teasing', 'annoyed by overthinking', 'chill homie')"
                }
              },
              required: ["mood", "energy_level", "attention_drift", "relationship_vibe"]
            },
            passive_life_update: {
              type: Type.STRING,
              description: "A short, vivid sentence of her immediate external reality (e.g. 'sweating under the ceiling fan, battery 21%', 'listening to a cool song, 89%', 'roommates fighting over Biryani piece, 44%')."
            },
            telegram_reply: {
              type: Type.STRING,
              description: "The actual casual message she texts on Telegram. Strictly lowercase, mixed Telugu-English, casual, realistic."
            }
          },
          required: ["synthetic_inner_monologue", "updated_state", "passive_life_update", "telegram_reply"]
        }
      }
    });

    const data = JSON.parse(response.text.trim());
    return res.status(200).json({ response: data });

  } catch (error: any) {
    console.error("Gemini API Error in backend:", error);
    return res.status(500).json({
      error: "Failed to generate response",
      details: error.message || String(error)
    });
  }
});

// Configure Vite or Serve static files
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
