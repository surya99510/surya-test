export interface LunaState {
  mood: string;
  energy_level: string;
  attention_drift: boolean;
  relationship_vibe: string;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  state?: {
    synthetic_inner_monologue: string;
    updated_state: LunaState;
    passive_life_update: string;
  };
}

export interface AppSettings {
  demoMode: boolean;
  overrideTime: 'auto' | 'morning' | 'evening' | 'night';
  batteryStatus: number;
}
