import React, { useState, useEffect, useRef } from "react";
import {
  Send,
  Check,
  CheckCheck,
  Cpu,
  Battery,
  Clock,
  Trash2,
  RefreshCw,
  AlertCircle,
  Sparkles,
  BookOpen,
  Info,
  Calendar,
  Zap,
  HelpCircle,
  Menu,
  ChevronRight,
  User,
  Power,
  ChevronDown,
  Smile
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Message, LunaState, AppSettings } from "./types";

const INITIAL_MESSAGES = (formattedTime: string): Message[] => [
  {
    id: "init-1",
    role: "assistant",
    content: "rey! enti inka melkoni unnav, nidra ratledha? 😭",
    timestamp: formattedTime,
    state: {
      synthetic_inner_monologue: "user text check chesa. it is quite late in Kakinada. usually everyone sleeps but this guy is texting. let me reply with low energy sleepy vibe because that's realistic. i was scrolling through funny reels anyway.",
      updated_state: {
        mood: "sleepy but chill",
        energy_level: "low",
        attention_drift: false,
        relationship_vibe: "night text buddies"
      },
      passive_life_update: "lying on hostel bed scrolling reels under the slow ceiling fan, battery 84%"
    }
  }
];

export default function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isSending, setIsSending] = useState(false);
  
  // App configurations and overrides
  const [demoMode, setDemoMode] = useState(false);
  const [overrideTime, setOverrideTime] = useState<"auto" | "morning" | "evening" | "night">("auto");
  const [examTension, setExamTension] = useState(false);
  const [customBattery, setCustomBattery] = useState(74);
  const [apiKeyWarning, setApiKeyWarning] = useState(false);

  // Inspector States
  const [selectedMessageId, setSelectedMessageId] = useState<string | null>("init-1");
  const [showMindConsole, setShowMindConsole] = useState(true);
  const [activeTab, setActiveTab] = useState<"thoughts" | "tuner" | "about">("thoughts");
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Get formatted local time string based on override setting
  const getSimulatedTime = () => {
    const now = new Date();
    if (overrideTime === "morning") {
      return "Thursday, 08:45 AM";
    }
    if (overrideTime === "evening") {
      return "Wednesday, 06:15 PM";
    }
    if (overrideTime === "night") {
      return "Wednesday, 01:20 AM";
    }
    // Auto (use the actual date format)
    return now.toLocaleString("en-US", {
      weekday: "long",
      hour: "2-digit",
      minute: "2-digit",
      hour12: true
    });
  };

  // Get human-readable simulated hours for logic checks
  const getSimulatedHour24 = () => {
    const now = new Date();
    if (overrideTime === "morning") return 8;
    if (overrideTime === "evening") return 18;
    if (overrideTime === "night") return 1;
    return now.getHours();
  };

  // Initialize messages and config from localStorage
  useEffect(() => {
    const savedMessages = localStorage.getItem("luna_telegram_chats");
    const savedDemo = localStorage.getItem("luna_config_demo");
    const savedTime = localStorage.getItem("luna_config_time");
    const savedExams = localStorage.getItem("luna_config_exams");
    const savedBattery = localStorage.getItem("luna_config_battery");

    if (savedDemo) setDemoMode(savedDemo === "true");
    if (savedTime) setOverrideTime(savedTime as any);
    if (savedExams) setExamTension(savedExams === "true");
    if (savedBattery) setCustomBattery(parseInt(savedBattery, 10));

    if (savedMessages) {
      try {
        const parsed = JSON.parse(savedMessages);
        if (parsed.length > 0) {
          setMessages(parsed);
          setSelectedMessageId(parsed[parsed.length - 1].id);
          return;
        }
      } catch (err) {
        console.error("Failed to parse saved chats:", err);
      }
    }

    // Default initializer
    const timeStr = getSimulatedTime();
    const defaults = INITIAL_MESSAGES(timeStr);
    setMessages(defaults);
    setSelectedMessageId("init-1");
  }, []);

  // Save changes to localStorage on update
  useEffect(() => {
    if (messages.length > 0) {
      localStorage.setItem("luna_telegram_chats", JSON.stringify(messages));
    }
  }, [messages]);

  // Scroll to bottom on updates
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isSending]);

  // Save overrides inside client localStorage
  const handleConfigChange = (key: string, val: any) => {
    localStorage.setItem(`luna_config_${key}`, String(val));
  };

  // Determine active mood, thoughts and environmental context from selected message
  const activeMessage = messages.find(m => m.id === selectedMessageId) || messages[messages.length - 1];
  const activeStateObj = activeMessage?.state || {
    synthetic_inner_monologue: "just waiting for user to send something...",
    updated_state: {
      mood: "calm",
      energy_level: "medium",
      attention_drift: false,
      relationship_vibe: "passive text bud"
    },
    passive_life_update: "looking at Telegram screen, battery " + customBattery + "%"
  };

  // Handle Clears
  const clearChatHistory = () => {
    if (window.confirm("Do you want to reset Luna's memory and chat history?")) {
      const timeStr = getSimulatedTime();
      const defaults = INITIAL_MESSAGES(timeStr);
      setMessages(defaults);
      setSelectedMessageId("init-1");
    }
  };

  // Quick replies suggested to the user so they text in style
  const QUICK_SUGGESTIONS = [
    { text: "tinava? em dinnam direct chesav 😋", type: "food" },
    { text: "em chestunav re... college continuous class ye na? 🥱", type: "college" },
    { text: "bro mood sariya ledhu, match lo dhoni out aindu 😭", type: "drama" },
    { text: "exams tension start aindi kada, inka scrolling reel aa? 💀", type: "exam" },
    { text: "paduko inka, too late aindi! bye 😴", type: "care" }
  ];

  const handleQuickSend = (text: string) => {
    if (isSending) return;
    setInputValue(text);
    handleSendMessage(text);
  };

  // Chat request sender
  const handleSendMessage = async (customText?: string) => {
    const textToSend = (customText || inputValue).trim();
    if (!textToSend || isSending) return;

    setInputValue("");
    setIsSending(true);

    const now = new Date();
    const formattedUserTime = getSimulatedTime();

    // 1. Add User Message to stream
    const userMsgId = `usr-${Date.now()}`;
    const newUserMessage: Message = {
      id: userMsgId,
      role: "user",
      content: textToSend,
      timestamp: formattedUserTime
    };

    const currentHistory = [...messages, newUserMessage];
    setMessages(currentHistory);
    setSelectedMessageId(userMsgId);

    // Create the mental context state to send to our brain endpoint
    const lastLunaMsg = [...messages].reverse().find(m => m.role === "assistant");
    const previousStateContext = lastLunaMsg?.state?.updated_state || {
      mood: "neutral",
      energy_level: "medium",
      attention_drift: false,
      relationship_vibe: "casual texter"
    };

    // Inject override constraints dynamically into state context
    const enrichedPreviousState = {
      ...previousStateContext,
      simulatedSystemOverridenTime: getSimulatedTime(),
      simulatedBatteryStatus: `${customBattery}%`,
      simulatedExamTensionEnabled: examTension
    };

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: currentHistory.map(m => ({ role: m.role, content: m.content })),
          previousState: enrichedPreviousState,
          localTimeLong: getSimulatedTime(),
          demoMode: demoMode
        })
      });

      if (!response.ok) {
        throw new Error("Backend response error status " + response.status);
      }

      const data = await response.json();

      if (data.apiKeyMissing) {
        setApiKeyWarning(true);
      }

      if (data.response) {
        const botMsgId = `luna-${Date.now()}`;
        const newBotMessage: Message = {
          id: botMsgId,
          role: "assistant",
          content: data.response.telegram_reply,
          timestamp: getSimulatedTime(),
          state: {
            synthetic_inner_monologue: data.response.synthetic_inner_monologue,
            updated_state: data.response.updated_state,
            passive_life_update: data.response.passive_life_update
          }
        };

        setMessages(prev => [...prev, newBotMessage]);
        setSelectedMessageId(botMsgId);
      }

    } catch (err: any) {
      console.error("Chat generation failed:", err);
      // Beautiful local fallback for continuous experience
      const errorBotMsgId = `luna-err-${Date.now()}`;
      setMessages(prev => [
        ...prev,
        {
          id: errorBotMsgId,
          role: "assistant",
          content: "reyy signal block direct aindi hostel room lo... retry chey malla! 😭 (API failure state check)",
          timestamp: getSimulatedTime(),
          state: {
            synthetic_inner_monologue: "backend connection range loose aindi. my mind is having compilation errors. need to trigger error handling fallback casually.",
            updated_state: {
              mood: "annoyed by signal drop",
              energy_level: "medium",
              attention_drift: true,
              relationship_vibe: "groping in dark room"
            },
            passive_life_update: "looking at Wi-Fi loose lights blinking, Kakinada hostels, battery 99%",
          }
        }
      ]);
      setSelectedMessageId(errorBotMsgId);
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="flex h-screen w-full flex-col bg-[#0b141a] font-sans md:flex-row overflow-hidden select-none">
      
      {/* LEFT: Telegram simulator screen */}
      <div className={`flex h-full flex-1 flex-col border-r border-[#222e35] transition-all duration-300 ${showMindConsole ? "lg:w-7/12" : "w-full"}`}>
        
        {/* Telegram Header */}
        <div className="flex h-[60px] shrink-0 items-center justify-between bg-[#202c33] px-3 shadow-md md:px-4 z-10">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&crop=face&fit=crop"
                alt="Luna Profile"
                className="h-10 w-10 rounded-full object-cover ring-2 ring-[#00a884] focus:outline-none"
                referrerPolicy="no-referrer"
              />
              <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-[#202c33] bg-[#00e676]" />
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <span className="font-semibold text-gray-150 text-[15px] sm:text-[16px] tracking-wide text-white">luna 🌸</span>
                <span className="rounded-full bg-[#2a3942] px-1.5 py-[1px] text-[9px] text-[#00a884] font-mono tracking-tighter">CODENAME: LUNA</span>
              </div>
              <p className="text-[11px] sm:text-xs text-[#00a884] font-medium leading-none flex items-center gap-1">
                {isSending ? (
                  <>
                    <span className="inline-block h-1.5 w-1.5 rounded-full bg-[#00a884] animate-ping" />
                    <span>typing thoughts in telugu slang...</span>
                  </>
                ) : (
                  <>
                    <span className="inline-block h-1.5 w-1.5 rounded-full bg-[#00e676]" />
                    <span>online • Kakinada, AP</span>
                  </>
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 sm:space-x-3">
            {/* API Warning badge */}
            {apiKeyWarning && (
              <span className="hidden xl:flex items-center text-xs text-amber-400 bg-amber-950/40 px-2 py-1 rounded gap-1 border border-amber-800">
                <AlertCircle size={12} />
                <span>Demo Mode Live</span>
              </span>
            )}
            
            <button
              onClick={() => setShowMindConsole(!showMindConsole)}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-semibold select-none transition-colors duration-200 ${
                showMindConsole 
                  ? "bg-[#00a884] text-white hover:bg-[#008f72]" 
                  : "bg-[#2a3942] text-gray-200 hover:bg-[#374953]"
              }`}
            >
              <Cpu size={14} className={isSending ? "animate-spin" : ""} />
              <span>{showMindConsole ? "Hide Brain" : "Mind Console"}</span>
            </button>

            <button
              onClick={clearChatHistory}
              title="Reset Chat & Memory"
              className="p-1.5 rounded-md text-gray-400 hover:bg-[#2a3942] hover:text-red-400 transition-all duration-150"
            >
              <Trash2 size={16} />
            </button>
          </div>
        </div>

        {/* Telegram Chat Wallpaper Area */}
        <div 
          className="flex-1 overflow-y-auto px-4 py-4 bg-[#0b141a] relative"
          style={{
            backgroundImage: "url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png')",
            backgroundRepeat: "repeat",
            backgroundSize: "400px",
            backgroundBlendMode: "overlay",
            backgroundColor: "#0b141a"
          }}
        >
          {/* Introductory Guide Card */}
          <div className="max-w-[420px] mx-auto mb-6 bg-[#1f2c34]/90 backdrop-blur-sm border border-[#2a3942] rounded-xl p-4 text-center shadow-lg transition hover:border-[#384b56]">
            <Sparkles className="mx-auto text-[#00a884] mb-2" size={24} />
            <h3 className="font-semibold text-sm text-gray-100">Synthetic Personality Simulator - Luna</h3>
            <p className="text-[11px] sm:text-xs text-gray-300 mt-1.5 leading-relaxed">
              Luna simulates a 22-year-old Telugu college girl from Kakinada. Text her like a friend! 
              Click on any message she sends to inspect her <strong className="text-[#00a884]">Inner Monologue</strong>, update dials, and see her environmental mood swings first-hand.
            </p>
            <div className="mt-3 flex items-center justify-center space-x-2">
              <span className="text-[9px] bg-[#2a3942] text-gray-300 px-2 py-0.5 rounded-full font-mono">Mixed Telugu-English Context</span>
              <span className="text-[9px] bg-[#2a3942] text-gray-300 px-2 py-0.5 rounded-full font-mono">Cognitive Feedback</span>
            </div>
          </div>

          <div className="space-y-3.5 max-w-[650px] mx-auto">
            <AnimatePresence initial={false}>
              {messages.map((msg) => {
                const isLuna = msg.role === "assistant";
                const isSelected = selectedMessageId === msg.id;

                return (
                  <motion.div
                    key={msg.id}
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.18 }}
                    className={`flex flex-col ${isLuna ? "items-start" : "items-end"}`}
                  >
                    <div 
                      onClick={() => {
                        if (isLuna) setSelectedMessageId(msg.id);
                      }}
                      className={`max-w-[85%] rounded-lg px-3 py-2 text-sm shadow-sm cursor-pointer transition-all duration-150 hover:brightness-110 relative ${
                        isLuna 
                          ? `bg-[#202c33] text-[#e9edef] rounded-tl-none border-l-2 ${isSelected ? "border-[#00a884] bg-[#25353f]" : "border-transparent"}` 
                          : "bg-[#005c4b] text-[#e9edef] rounded-tr-none hover:shadow-md"
                      }`}
                    >
                      {/* Interactive thought marker badge */}
                      {isLuna && msg.state && (
                        <div className="absolute -top-2 -right-1 flex space-x-1">
                          <span className="text-[8px] bg-[#00a884]/90 text-white font-mono px-1 py-0.2 rounded shadow">
                            thought log
                          </span>
                        </div>
                      )}

                      <p className="whitespace-pre-wrap leading-relaxed text-[13.5px] sm:text-[14px]">
                        {msg.content}
                      </p>
                      
                      <div className="flex items-center justify-end space-x-1 mt-1 text-[9.5px] text-gray-400 font-mono leading-none">
                        <span>{msg.timestamp.split(", ")[1] || msg.timestamp}</span>
                        {!isLuna && (
                          <span className="text-[#53bdeb]">
                            <CheckCheck size={11} />
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Expand thought inline toggle click link */}
                    {isLuna && msg.state && isSelected && (
                      <motion.div 
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        className="mt-1 px-2.5 max-w-[85%]"
                      >
                        <p className="text-[10px] text-[#00a884] font-mono leading-relaxed bg-[#1b2b34] p-2 rounded-md border border-[#00a884]/25">
                          <strong className="text-[#53bdeb]">🌙 Luna's Thought:</strong> "{msg.state.synthetic_inner_monologue}"
                        </p>
                      </motion.div>
                    )}
                  </motion.div>
                );
              })}
            </AnimatePresence>

            {isSending && (
              <div className="flex items-start">
                <div className="bg-[#202c33] max-w-[30%] rounded-lg rounded-tl-none px-3 py-2.5 shadow-sm text-sm border-l-2 border-[#00a884]">
                  <div className="flex space-x-1.5 items-center justify-center h-4">
                    <span className="h-1.5 w-1.5 rounded-full bg-[#00a884] animate-bounce" style={{ animationDelay: "0ms" }} />
                    <span className="h-1.5 w-1.5 rounded-full bg-[#00a884] animate-bounce" style={{ animationDelay: "150ms" }} />
                    <span className="h-1.5 w-1.5 rounded-full bg-[#00a884] animate-bounce" style={{ animationDelay: "300ms" }} />
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* Telegram Chat Input Workspace */}
        <div className="bg-[#202c33] p-2.5 border-t border-[#2a3942] z-10 select-none">
          {/* Quick Slang Recommendations */}
          <div className="flex items-center space-x-2 overflow-x-auto pb-1.5 mb-1.5 no-scrollbar max-w-full">
            <span className="text-[10px] text-[#00a884] flex items-center shrink-0 font-bold tracking-tight uppercase gap-0.5">
              <Zap size={10} />
              <span>Nudges:</span>
            </span>
            {QUICK_SUGGESTIONS.map((sug, idx) => (
              <button
                key={idx}
                disabled={isSending}
                onClick={() => handleQuickSend(sug.text)}
                className="shrink-0 bg-[#2a3942] hover:bg-[#374953] border border-[#384b56] text-[11px] text-gray-200 px-3 py-1 rounded-full text-left transition"
              >
                {sug.text}
              </button>
            ))}
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center space-x-2"
          >
            {/* Attachment paperclip (pure design style) */}
            <button
              type="button"
              onClick={() => alert("naa system strictly uses textual cognitive feedback sanna... stick to keyboards! 😭")}
              className="p-2 rounded-full text-gray-400 hover:bg-[#2a3942] hover:text-[#00a884] shrink-0 transition"
            >
              <Smile size={20} />
            </button>

            {/* Input TextBox */}
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              disabled={isSending}
              placeholder="Type message in Telugu-English (slang text viz em chestunav)..."
              style={{ fontSize: "14px" }}
              className="flex-1 bg-[#2a3942] text-white rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[#00a884] border-transparent placeholder-gray-400"
            />

            {/* Send Telegram Button */}
            <button
              type="submit"
              disabled={isSending || !inputValue.trim()}
              className={`p-2 rounded-full flex items-center justify-center shrink-0 transition-all ${
                inputValue.trim() && !isSending 
                  ? "bg-[#0088cc] hover:bg-[#0077b5] text-white cursor-pointer active:scale-95" 
                  : "bg-transparent text-gray-400 cursor-not-allowed"
              }`}
            >
              <Send size={18} />
            </button>
          </form>
        </div>
      </div>

      {/* RIGHT: Synthetic mind diagnostics portal (Luna Core Console) */}
      <AnimatePresence>
        {showMindConsole && (
          <motion.div
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: "inherit", opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="flex h-full w-full flex-col bg-[#121b22] shrink-0 lg:w-[410px] border-t border-[#222e35] md:border-t-0 select-none overflow-hidden"
          >
            {/* Diagnostics Header */}
            <div className="flex h-[60px] cursor-default items-center justify-between border-b border-[#222e35] bg-[#1a232a] px-4 font-mono">
              <div className="flex items-center space-x-2">
                <Cpu className="text-[#00a884]" size={16} />
                <span className="text-[12px] font-bold text-gray-200 tracking-wider">LUNA_CORE_V1.02</span>
              </div>
              <div className="flex items-center space-x-1 text-[10px] text-[#00a884] font-medium bg-[#00a884]/10 border border-[#00a884]/30 px-2 py-0.5 rounded">
                <span className="h-1.5 w-1.5 rounded-full bg-[#00e676] animate-pulse" />
                <span>ACTIVE_STATE</span>
              </div>
            </div>

            {/* Diagnostics Tabs */}
            <div className="flex border-b border-[#222e35] bg-[#151e24] text-[11px] font-mono">
              <button
                onClick={() => setActiveTab("thoughts")}
                className={`flex-1 py-2.5 text-center transition ${
                  activeTab === "thoughts" 
                    ? "bg-[#1f2c34] text-[#00a884] font-bold border-b-2 border-[#00a884]" 
                    : "text-gray-400 hover:bg-[#1a252c]"
                }`}
              >
                ⚡ Live Mind
              </button>
              <button
                onClick={() => setActiveTab("tuner")}
                className={`flex-1 py-2.5 text-center transition ${
                  activeTab === "tuner" 
                    ? "bg-[#1f2c34] text-[#00a884] font-bold border-b-2 border-[#00a884]" 
                    : "text-gray-400 hover:bg-[#1a252c]"
                }`}
              >
                ⚙️ Neural Tuner
              </button>
              <button
                onClick={() => setActiveTab("about")}
                className={`flex-1 py-2.5 text-center transition ${
                  activeTab === "about" 
                    ? "bg-[#1f2c34] text-[#00a884] font-bold border-b-2 border-[#00a884]" 
                    : "text-gray-400 hover:bg-[#1a252c]"
                }`}
              >
                ℹ️ Architecture
              </button>
            </div>

            {/* TAB CONTENT PANEL AREA */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar bg-[#121b22]">
              
              {activeTab === "thoughts" && (
                <>
                  {/* Cognitive load badges */}
                  <div className="bg-[#1a232a] border border-[#222e35] rounded-lg p-3.5 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono text-gray-400">COGNITIVE RATINGS</span>
                      <span className="text-[9px] font-mono text-[#00a884] bg-[#00a884]/15 px-1.5 py-0.5 rounded">
                        DYNAMIC_ALIGNED
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2.5 font-mono">
                      {/* Mood Indicator */}
                      <div className="p-2 border border-[#222e35] rounded bg-[#151e24]">
                        <span className="text-[9px] text-gray-400 block tracking-tight">MOOD STATE</span>
                        <span className="text-xs font-bold text-[#e9edef] capitalize flex items-center space-x-1.5 mt-0.5">
                          <span className="h-1.5 w-1.5 rounded-full bg-blue-400" />
                          <span>{activeStateObj.updated_state.mood}</span>
                        </span>
                      </div>

                      {/* Energy Level indicator */}
                      <div className="p-2 border border-[#222e35] rounded bg-[#151e24]">
                        <span className="text-[9px] text-gray-400 block tracking-tight">ENERGY STATE</span>
                        <span className="text-xs font-bold text-[#e9edef] capitalize flex items-center space-x-1.5 mt-0.5">
                          <span className={`h-1.5 w-1.5 rounded-full ${activeStateObj.updated_state.energy_level === "high" ? "bg-green-400" : activeStateObj.updated_state.energy_level === "low" ? "bg-red-400" : "bg-yellow-400"}`} />
                          <span className="uppercase">{activeStateObj.updated_state.energy_level}</span>
                        </span>
                      </div>

                      {/* Relationship indicator */}
                      <div className="p-2 border border-[#222e35] rounded bg-[#151e24] col-span-2">
                        <span className="text-[9px] text-gray-400 block tracking-tight">RELATIONSHIP VIBE</span>
                        <span className="text-xs font-bold text-[#53bdeb] mt-0.5 block truncate">
                          {activeStateObj.updated_state.relationship_vibe}
                        </span>
                      </div>
                    </div>

                    {/* Attention drift alert flag */}
                    <div className={`p-2 border rounded flex items-center justify-between text-[11px] font-mono ${
                      activeStateObj.updated_state.attention_drift 
                        ? "bg-amber-950/20 border-amber-800 text-amber-300" 
                        : "bg-emerald-950/25 border-emerald-900 text-emerald-300"
                    }`}>
                      <span className="font-bold flex items-center space-x-1.5">
                        <span className={`h-2 w-2 rounded-full ${activeStateObj.updated_state.attention_drift ? "bg-amber-500 animate-ping" : "bg-emerald-500"}`} />
                        <span>ATTENTION DETECTOR:</span>
                      </span>
                      <span>
                        {activeStateObj.updated_state.attention_drift ? "⚠️ DRIFTED (REELS)" : "🎯 FOCUS_ALIGNED"}
                      </span>
                    </div>
                  </div>

                  {/* Environment metrics */}
                  <div className="bg-[#1a232a] border border-[#222e35] rounded-lg p-3 space-y-2.5 font-mono text-[11px]">
                    <span className="text-[10px] text-gray-450 uppercase block text-gray-400 leading-none">External Environment Tracker</span>
                    <div className="divide-y divide-[#2a3942] space-y-1.5">
                      <div className="flex justify-between py-1">
                        <span className="text-gray-400">Current Position:</span>
                        <span className="text-gray-200">Kakinada Girls Hostel, AP</span>
                      </div>
                      <div className="flex justify-between pt-1.5">
                        <span className="text-gray-400">Active Task:</span>
                        <span className="text-[#00a884] truncate max-w-[200px]">{activeStateObj.passive_life_update}</span>
                      </div>
                      <div className="flex justify-between pt-1.5">
                        <span className="text-gray-400">Simulated Date & Time:</span>
                        <span className="text-gray-200 flex items-center space-x-1">
                          <Clock size={11} /> 
                          <span>{getSimulatedTime()}</span>
                        </span>
                      </div>
                      <div className="flex justify-between pt-1.5">
                        <span className="text-gray-400">Battery Status:</span>
                        <span className="text-gray-200 flex items-center space-x-1">
                          <Battery size={11} className={customBattery < 20 ? "text-red-500" : "text-green-500"} />
                          <span>{customBattery}%</span>
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Neural inner monologue (Unfiltered Thoughts terminal) */}
                  <div className="bg-[#0b141a] border border-[#222e35] rounded-lg overflow-hidden flex flex-col h-[280px]">
                    <div className="bg-[#1a232a] border-b border-[#222e35] px-3 py-1.5 flex items-center justify-between font-mono text-[11px]">
                      <span className="font-bold text-[#53bdeb] flex items-center gap-1.5">
                        <Sparkles size={11} className="animate-pulse" />
                        <span>UNFILTERED_THOUGHT_MONOLOGUE.LOG</span>
                      </span>
                      <span className="text-[#00a884] text-[9px] animate-pulse">● FEEDING_STREAM</span>
                    </div>
                    
                    <div className="flex-1 p-3 font-mono text-[11.5px] text-[#00e676] overflow-y-auto leading-relaxed scrollbar-thin scrollbar-thumb-gray-800 bg-[#080f14]">
                      <div className="text-gray-500 mb-1">
                        [{new Date().toLocaleTimeString()}] INGESTING RECENT RAW INTERACTIONS...
                      </div>
                      <div className="text-cyan-400 mb-2">
                        [STATE CONTEXT OVERRIDE: OK] mood={activeStateObj.updated_state.mood} | attention_drift={String(activeStateObj.updated_state.attention_drift)}
                      </div>
                      <div className="font-sans text-gray-200 pl-1 border-l border-emerald-900 leading-relaxed italic text-[12.5px]">
                        "{activeStateObj.synthetic_inner_monologue}"
                      </div>
                      <div className="mt-3 inline-block bg-[#1f2c34] text-white text-[10px] py-0.5 px-2 rounded-full cursor-default border border-[#384b56]">
                        {isSending ? "Calculating next thoughts..." : "Select messages on left to scroll monologue logs"}
                      </div>
                    </div>
                  </div>
                </>
              )}

              {activeTab === "tuner" && (
                <div className="bg-[#1a232a] border border-[#222e35] rounded-lg p-4 space-y-4 font-mono text-xs text-gray-200">
                  <div className="border-b border-[#222e35] pb-2">
                    <h3 className="font-bold text-gray-100 flex items-center gap-1.5">
                      <Zap size={14} className="text-[#00a884]" />
                      <span>SYNTHETIC NEURAL TUNING</span>
                    </h3>
                    <p className="text-[10px] text-gray-400 mt-1 leading-snug">
                      Nudge her environmental variables and configurations. This influences prompt generation directly!
                    </p>
                  </div>

                  <div className="space-y-4">
                    {/* Simulated Time Selector */}
                    <div className="space-y-1.5">
                      <label className="text-[11px] text-gray-400 uppercase tracking-wide">
                        Simulate Hour/Time Phase
                      </label>
                      <div className="grid grid-cols-2 gap-1.5">
                        {(["auto", "morning", "evening", "night"] as const).map((t) => (
                          <button
                            key={t}
                            onClick={() => {
                              setOverrideTime(t);
                              handleConfigChange("time", t);
                            }}
                            className={`py-1.5 px-2 rounded border text-center font-mono capitalize transition ${
                              overrideTime === t 
                                ? "bg-[#00a884]/20 border-[#00a884] text-[#00a884] font-bold" 
                                : "bg-[#151e24] border-[#222e35] text-gray-400 hover:bg-[#1a252c]"
                            }`}
                          >
                            {t === "auto" ? "⏱️ Real Time" : t}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Examp Tension Switch */}
                    <div className="flex items-center justify-between p-2.5 bg-[#151e24] border border-[#222e35] rounded">
                      <div>
                        <span className="font-bold block text-[#53bdeb] text-[11.5px]">Semester Exams Pending</span>
                        <span className="text-[9.5px] text-gray-400 leading-none">Increases student panic level / dry moods</span>
                      </div>
                      <button
                        onClick={() => {
                          const nextVal = !examTension;
                          setExamTension(nextVal);
                          handleConfigChange("exams", nextVal);
                        }}
                        className={`text-[10px] px-3 py-1 rounded transition font-bold ${
                          examTension 
                            ? "bg-red-500 text-white" 
                            : "bg-[#2a3942] text-gray-300"
                        }`}
                      >
                        {examTension ? "STRESSED" : "RELAXED"}
                      </button>
                    </div>

                    {/* Battery Status Slider override */}
                    <div className="space-y-1.5 bg-[#151e24] p-2.5 border border-[#222e35] rounded">
                      <div className="flex justify-between items-center text-[11px]">
                        <span className="font-bold text-gray-200">Luna's Battery level:</span>
                        <span className={`font-mono font-bold ${customBattery < 20 ? "text-red-500 animate-pulse" : "text-[#00a884]"}`}>
                          {customBattery}%
                        </span>
                      </div>
                      <input
                        type="range"
                        min="5"
                        max="100"
                        value={customBattery}
                        onChange={(e) => {
                          const n = parseInt(e.target.value, 10);
                          setCustomBattery(n);
                          handleConfigChange("battery", n);
                        }}
                        className="w-full accent-[#00a884] cursor-pointer"
                      />
                      <span className="text-[9px] text-gray-400 block leading-tight">
                        Under 15% causes battery-grumping comments in text.
                      </span>
                    </div>

                    {/* Safe Demo Toggle for Key missing fallback */}
                    <div className="flex items-center justify-between p-2.5 bg-[#151e24] border border-[#222e35] rounded">
                      <div>
                        <span className="font-bold block text-gray-200 text-[11.5px]">Safe Offline Demo</span>
                        <span className="text-[9.5px] text-gray-400 leading-none">Uses offline precompiled messages</span>
                      </div>
                      <button
                        onClick={() => {
                          const nd = !demoMode;
                          setDemoMode(nd);
                          handleConfigChange("demo", nd);
                        }}
                        className={`text-[10px] px-3 py-1 rounded font-bold transition ${
                          demoMode 
                            ? "bg-[#0088cc] text-white" 
                            : "bg-[#2a3942] text-gray-300"
                        }`}
                      >
                        {demoMode ? "DEMO_ON" : "OFF (GEMINI)"}
                      </button>
                    </div>

                    {/* API keys setup guidelines */}
                    <div className="p-3 bg-emerald-950/15 border border-[#00a884]/30 rounded-lg text-[10.5px] leading-relaxed text-gray-300 space-y-1 bg-teal-980/10">
                      <span className="font-bold text-[#00a884] flex items-center gap-1">
                        <Info size={12} />
                        <span>SYSTEM SECRET CHECKLIST</span>
                      </span>
                      <p>
                        Our backend leverages the Gemini API. Add your <strong className="text-white">GEMINI_API_KEY</strong> inside AI Studio's **Settings (Gear Icon) &gt; Secrets** to unlock her true synthetic neural brain!
                      </p>
                    </div>

                  </div>
                </div>
              )}

              {activeTab === "about" && (
                <div className="bg-[#1a232a] border border-[#222e35] rounded-lg p-3.5 space-y-3 font-sans text-xs text-gray-300 leading-relaxed">
                  <h3 className="font-bold font-mono text-gray-150 border-b border-[#222e35] pb-1 text-white">
                    🔬 CODENAME: LUNA ARCHITECTURE
                  </h3>
                  <p>
                    <strong>Luna</strong> is powered by a custom-prompted **Synthetic Personality Architecture** running over Google's Gemini Models. Unlike generic chatbots, she maintains an integrated "Continuous Internal Mind state" consisting of:
                  </p>
                  <ul className="list-disc list-inside space-y-1.5 PL-1 text-gray-200">
                    <li>
                      <strong className="text-[#00a884]">Unfiltered Inner Monologue</strong>: A continuous flow of micro-thoughts where she analyzes the user behavior, parses her sleep status, and reasons before drafting messages.
                    </li>
                    <li>
                      <strong className="text-[#00a884]">Continuous Status-State Momentum</strong>: Her fatigue, distraction levels (attention drift), and relationship warmth evolve step-by-step rather than resetting.
                    </li>
                    <li>
                      <strong className="text-[#00a884]">Localized Slang Engine</strong>: Organic mixing of English with modern Telugu college expressions like <em>tinava, em chestunav re, bro overthink chestunav</em>.
                    </li>
                  </ul>
                  <div className="pt-2 text-[10px] font-mono text-gray-400">
                    Build Team: Antigravity AI Studio Workspace.
                  </div>
                </div>
              )}

            </div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
